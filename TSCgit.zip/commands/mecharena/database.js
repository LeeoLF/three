const { ActionRowBuilder, ButtonBuilder, ButtonStyle, SlashCommandBuilder } = require('discord.js');
//const { rocha, footer } = require('./index.js');

module.exports = {
    cooldown: 10,
    data: new SlashCommandBuilder()
        .setName('database')
        .setDescription('Show the Mech Arena Spreadsheet'),
    async execute(interaction) { 
    const button = new ButtonBuilder()
	        .setLabel('Click Here')
	        .setURL('https://docs.google.com/spreadsheets/u/1/d/e/2PACX-1vSSkn0ADktTq2CMr8VOObb8i0HKIseT-7ZJBYIRa8hkO4sFF3Z2ZScvWmcrDT81OHEc6N0dBYnzY6ga/pubhtml')
	        .setStyle(ButtonStyle.Link);
	    
	    const row = new ActionRowBuilder()
			.addComponents(button);
	        
        //Embed
        const embed = {
            color: 0xFF0000,
            title: 'Spreadsheet Mech Arena',
            description: `Click the Button Below!\nThis Button will take you to the Spreadsheet created by Scape211`,
            //footer: { text: `${footer}` },
            thumbnail: {
                url: 'https://store.plarium.com/_next/image/?url=https%3A%2F%2Fcdn04.x-plarium.com%2Fproduction%2Fwebstore%2Farena%2FIconApp.png&w=128&q=75',
            },
        };
        
        interaction.reply({ embeds: [embed], components: [row]});

},
};
