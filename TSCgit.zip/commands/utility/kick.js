const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    cooldown: 5,
    data: new SlashCommandBuilder()
        .setName('kick')
        .setDescription('Kicka um usuário do servidor')
        .addUserOption(option =>
            option.setName('usuário')
                .setDescription('Usuário para kickar')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('razão')
                .setDescription('Razão do kick')
                .setRequired(false)),
    async execute(interaction) {
        const user = interaction.options.getUser('usuário');
        const reason = interaction.options.getString('razão') || 'Nenhuma razão fornecida';

        if (!interaction.member.permissions.has('KICK_MEMBERS')) {
            return await interaction.reply({ content: 'Você não tem permissão para kickar membros.', ephemeral: true });
        }

        if (!interaction.guild.me.permissions.has('KICK_MEMBERS')) {
            return await interaction.reply({ content: 'O bot não tem permissão para kickar membros.', ephemeral: true });
        }

        try {
            await interaction.guild.members.kick(user, { reason: reason });
            await interaction.reply({ content: `O usuário ${user.tag} foi kickado do servidor. Razão: ${reason}` });
        } catch (error) {
            console.error('Erro ao kickar usuário:', error);
            await interaction.reply({ content: 'Ocorreu um erro ao tentar kickar o usuário.', ephemeral: true });
        }
    },
};