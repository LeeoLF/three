const { SlashCommandBuilder } = require('discord.js');

module.exports = {
        data: new SlashCommandBuilder()
                .setName('server')
                .setDescription('Provides information about the server.'),
        async execute(interaction) {
                await interaction.reply(`This server is ${interaction.guild.name} and has ${interaction.guild.memberCount} members.`);
        },
};
/*const { ActionRowBuilder, ButtonBuilder, ButtonStyle, SlashCommandBuilder } = require('discord.js');

module.exports = {
    cooldown: 10,
    data: new SlashCommandBuilder()
        .setName('server')
        .setDescription('Responde com Pong!'),
    async execute(interaction) {
        // Envia a mensagem inicial "Pinging..."
        const sent = await interaction.reply({ content: 'Rules...', fetchReply: true });

        // Calcula a latência
        const latency = sent.createdTimestamp - interaction.createdTimestamp;
        
        const button = new ButtonBuilder()
	        .setLabel('Three')
	        .setURL('https://keepo.io/three/')
	        .setStyle(ButtonStyle.Link);
	    
	    const row = new ActionRowBuilder()
			.addComponents(button);
	        
        //Embed
        const embed = {
            color: 0xFF0000,
            title: 'Regras?',
            description: `Esse servidor não tem regras... não que eu saiba.\nSe tiver, me fala! rs`,
			footer: { text: 'Hosted by Square Cloud | Rocha' },
            /*thumbnail: {
                url: 'https://i.imgur.com/wSTFkRM.png', // URL da imagem
            },
        };

        // Edita a resposta para incluir o embed
        await interaction.editReply({ content: 'Existe...', embeds: [embed], components: [row]});
    },
};*/