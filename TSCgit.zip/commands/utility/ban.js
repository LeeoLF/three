const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    cooldown: 5,
    data: new SlashCommandBuilder()
        .setName('ban')
        .setDescription('Bane um usuário do servidor')
        .addUserOption(option =>
            option.setName('usuário')
                .setDescription('Usuário para banir')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('razão')
                .setDescription('Razão do banimento')
                .setRequired(false)),
    async execute(interaction) {
        const user = interaction.options.getUser('usuário');
        const reason = interaction.options.getString('razão') || 'Nenhuma razão fornecida';

        if (!interaction.member.permissions.has('BAN_MEMBERS')) {
            return await interaction.reply({ content: 'Você não tem permissão para banir membros.', ephemeral: true });
        }

        if (!interaction.guild.me.permissions.has('BAN_MEMBERS')) {
            return await interaction.reply({ content: 'O bot não tem permissão para banir membros.', ephemeral: true });
        }

        try {
            await interaction.guild.members.ban(user, { reason: reason });
            await interaction.reply({ content: `O usuário ${user.tag} foi banido do servidor. Razão: ${reason}` });
        } catch (error) {
            console.error('Erro ao banir usuário:', error);
            await interaction.reply({ content: 'Ocorreu um erro ao tentar banir o usuário.', ephemeral: true });
        }
    },
};