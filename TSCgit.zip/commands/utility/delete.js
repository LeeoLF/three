const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    cooldown: 5,
    data: new SlashCommandBuilder()
        .setName('delete')
        .setDescription('Limpa uma quantidade específica de mensagens do canal')
        .addIntegerOption(option =>
            option.setName('quantidade')
                .setDescription('Quantidade de mensagens para limpar')
                .setRequired(true)),
    async execute(interaction) {
        const amount = interaction.options.getInteger('quantidade');

        if (!interaction.member.permissions.has('MANAGE_MESSAGES')) {
            return await interaction.reply({ content: 'Você não tem permissão para gerenciar mensagens.', ephemeral: true });
        }

        if (amount <= 0 || amount > 100) {
            return await interaction.reply({ content: 'Por favor, forneça um número entre 1 e 100.', ephemeral: true });
        }

        try {
            await interaction.channel.bulkDelete(amount);
            await interaction.reply({ content: `Foram limpas ${amount} mensagens neste canal.`, ephemeral: true });
        } catch (error) {
            console.error('Erro ao limpar mensagens:', error);
            await interaction.reply({ content: 'Ocorreu um erro ao tentar limpar mensagens.', ephemeral: true });
        }
    },
};