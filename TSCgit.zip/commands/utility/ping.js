const { SlashCommandBuilder } = require('discord.js');
//const { rocha, footer } = require('/index.js');

module.exports = {
    cooldown: 10,
    data: new SlashCommandBuilder()
        .setName('ping')
        .setDescription('Responde com Pong!'),
    async execute(interaction) {
        // Envia a mensagem inicial "Pinging..."
        const sent = await interaction.reply({ content: 'Pinging...', fetchReply: true });

        // Calcula a latência
        const latency = sent.createdTimestamp - interaction.createdTimestamp;
        
        const button = new ButtonBuilder()
	        .setLabel('Three')
	        .setURL('https://keepo.io/three/')
	        .setStyle(ButtonStyle.Link);
	    
	    const row = new ActionRowBuilder()
			.addComponents(button);
	        
        //Embed
        const embed = {
            color: 0xFF0000,
            title: 'Pong!',
            description: `Latência de ida e volta: ${latency}\n\nHosted by **Square Cloud** | [Rocha](https://discord.com/users/886222304370130984)`,
            //footer: { text: 'Hosted by Square Cloud | Rocha' },
            /*thumbnail: {
                url: 'https://i.imgur.com/wSTFkRM.png', // URL da imagem
            },*/
        };

        // Edita a resposta para incluir o embed
        await interaction.editReply({ content: 'Pinging...', embeds: [embed], components: [row]});
    },
};