const { ActionRowBuilder, MessageActionRow, ButtonBuilder, ButtonStyle, SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('profile')
        .setDescription('Show user profile information.'),
    async execute(interaction) {
        const user = interaction.options.getUser('user') || interaction.user;
        const guildMember = interaction.guild.members.cache.get(user.id);

        const embed = {
            color: 0xFF0000,
            title: 'Profile of ' + user.tag,
            thumbnail: {
                url: user.displayAvatarURL({ dynamic: true })
            },
            description: `**ID:** ${user.id}\n**Username:** ${user.username}\n**Tag:** ${user.discriminator}\n**Account created at:** ${user.createdAt.toDateString()}`
        };

        const avatarButton = new ButtonBuilder()
            .setLabel('View Avatar')
            .setCustomId('view_avatar')
            .setStyle(ButtonStyle.Danger);

        const bannerButton = new ButtonBuilder()
            .setLabel('View Banner')
            .setCustomId('view_banner')
            .setStyle(ButtonStyle.Success);

        const row = new ActionRowBuilder()
            .addComponents(avatarButton)
            .addComponents(bannerButton);

        if(guildMember.banner) {
            bannerButton.setDisabled(false);
        } else {
            bannerButton.setDisabled(true);
        }

        await interaction.reply({ embeds: [embed], components: [row] });
    },
};